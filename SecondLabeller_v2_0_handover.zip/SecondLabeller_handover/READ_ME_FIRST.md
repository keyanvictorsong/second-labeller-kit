# Read me first

Thank you for helping. You have been asked to label 150 code locations for a research study on a security scanner.

## Before you start

1. **Extract the zip** and keep the folder in one place. Do not open the page from inside the zip: the browser would
   then lose your progress.
2. Use a current Chrome on a computer if you can: the page was tested in Chrome only. Use one tab.
3. Open `LABELLING_DESK.html` (double-click it). It needs no internet connection of its own. Each item has a link to
   the same file on GitHub, which you will want when a call has to be followed into another file.

## What you do

1. Read the codebook: it is the panel "Codebook" on the page and takes about ten minutes.
2. Fill in the first page and do the two practice items. Then, as the page asks, press "Download progress file" once
   and load that file back with "Load a progress file", to see that both work in your browser. If anything fails up to
   here, stop and tell the person who gave you this folder.
3. Label the items in the order shown.
4. On the last page, answer six statements about how you worked and press "Download answers file".
5. Send that one file back to the person who gave you this folder. If you export more than once, send the last file.

## How long

Most items take one to three minutes. Following a helper function through several files can take five to ten. Plan on
about four hours in all, in as many sittings as you like. At the end of each sitting press "Download progress file"
and keep the file: the browser keeps your progress too, but a file is safer, and it lets you go on in another browser.

**Please finish all 150 items if you can.** The study's statistics need the complete set; a part of it can only be
described.

## How to work

- Work alone.
- Use no AI assistant, chatbot or AI code completion for any item. That includes the AI features on GitHub's code
  pages (Copilot): read the code there, and do not ask it anything.
- Decide from the code. A function's name decides nothing until you have read its body.
- Do not ask the author what the expected answer is, and do not look for the study's paper or results before you have
  sent your file. Questions about how the page works are fine.
- If the code does not decide an item, there is a label `UNCLEAR`; the codebook asks to use it sparingly and to say
  why. There is also a confidence field and a note field.

## What the page records

Your answers; what you write on the first and the last page; and the time, by your computer's clock, when each item
was first shown, each time you saved it, and when the page was hidden or shown again. Nothing leaves your computer
until you send the answers file yourself.

## What happens with your answers

They are compared with labels that exist already and that you have not been shown. The comparison is reported in the
paper whatever it shows. The six statements are reported as your statements. The author will ask you before your name
is printed anywhere.
